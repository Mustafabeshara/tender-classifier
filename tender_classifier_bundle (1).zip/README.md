# Tender Classifier

Automates classification of tenders and quotations from Google Drive based on Arabic document patterns.

## Setup

1. Clone the repo
2. Set up virtual environment
3. Install requirements: `pip install -r requirements.txt`
4. Add `client_secrets.json`
5. Update folder ID in `TenderClassifier.py`
6. Run: `python TenderClassifier.py`
